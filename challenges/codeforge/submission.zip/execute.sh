#!/bin/bash

cd src
GO111MODULE=off go build -o blade script.go

cd ..
mkdir -p out
mv src/blade out