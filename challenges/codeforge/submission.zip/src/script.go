package main

import "fmt"

func main() {
	fmt.Println("Hello there... Welcome to Bashaway 2k24!")
}
