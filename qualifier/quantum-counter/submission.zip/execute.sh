grep -ow "$1" src/* | wc -w
