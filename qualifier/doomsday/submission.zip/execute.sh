#!/bin/bash

mkdir -p src
mkdir -p out

touch out/inventory

mkdir -p out/playbooks
touch out/playbooks/book

mkdir -p out/roles
touch out/roles/role

touch out/group_vars