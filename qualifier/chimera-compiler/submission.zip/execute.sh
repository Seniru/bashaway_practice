#!/bin/bash
echo 'HANDSHAKE:OK|WASM:READY'