#!/bin/bash
echo "$1" | tr 'A-Za-z' 'N-ZA-Mn-za-m'
